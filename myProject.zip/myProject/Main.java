public class Main {
    public static void main(String[] args) {
        System.out.println("Git is fun");
        System.out.println("Version 1 New update from GitHub");
        System.out.println("Version 2 New update from GitHub");

        for (int i = 0; i < 4; i++) {
            System.out.println("Meow");
        }

        System.out.println("Version 3 New update from GitHub");
    }
}